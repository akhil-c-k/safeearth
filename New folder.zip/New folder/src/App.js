import React,{useState,useEffect} from 'react';
import { BrowserRouter as Router, Route, Link, Switch } from "react-router-dom";
import logo from './logo.svg';
import './App.scss';
import Signin from './components/Signin'
import Signup from './components/Signup'
import Homepage from './components/Homepage'
import firebase from './firebase'

function App() {

  const [firebaseInitialized, setFirebaseInitialized] = useState(false)

	useEffect(() => {
		firebase.isInitialized().then(val => {
			setFirebaseInitialized(val)
		})
  })
  

  return (
    <div className="App">
       <Router>
         <Switch>
           <Route exact path="/" component={Homepage}/>
           <Route exact path="/login" component={Signin}/>
           <Route exact path="/signup" component={Signup}/>
         </Switch>
       </Router>
    </div>
  );
}

export default App;
