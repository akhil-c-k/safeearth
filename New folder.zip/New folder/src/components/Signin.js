import React, { useState }from 'react';
import firebase from '../firebase'
import "./Signin.scss"

const Signin = (props) => {

    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')
    
    return (
        <div className="userlog">
          <form>
          <input className="input-field" id="email" name="email" autoComplete="off" autoFocus value={email} placeholder="email" onChange={e => setEmail(e.target.value)} />
             <br/>
             <input className="input-field" name="password" type="password" id="password" autoComplete="off" placeholder="password" value={password} onChange={e => setPassword(e.target.value)} />
             <br/>
             <button className="" onClick={login}>Sign In</button>
          </form>
        </div>
    )

    async function login() {
		try {
			await firebase.login(email, password)
			props.history.replace('/dashboard')
		} catch(error) {
			alert(error.message)
		}
	}
}

export default Signin;