import React, { useState } from 'react'
import firebase from '../firebase'
import { Link, withRouter } from 'react-router-dom'
import "./Signin.scss"

const Signup = (props) => {

    const [name, setName] = useState('')
	const [email, setEmail] = useState('')
	const [password, setPassword] = useState('')
    

    return (
        <div className="userlog">
          <form>
             <input className="input-field" type="text" id="name" name="name" autoComplete="off" autoFocus value={name} onChange={e => setName(e.target.value)} />
             <br/>
             <input className="input-field" type="text" id="email" name="email" autoComplete="off" value={email} onChange={e => setEmail(e.target.value)} />
             <br/>
             <input className="input-field" name="password" type="password" id="password" autoComplete="off" value={password} onChange={e => setPassword(e.target.value)}  />
             <br/>
             <button className="">Sign Up</button>
          </form>
        </div>
    )

    async function onRegister() {
		try {
			await firebase.register(name, email, password)
			props.history.replace('/dashboard')
		} catch(error) {
			alert(error.message)
		}
	}
}

export default withRouter(Signup);